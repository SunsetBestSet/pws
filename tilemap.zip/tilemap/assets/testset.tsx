<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="testmap" tilewidth="32" tileheight="32" tilecount="216" columns="18">
 <image source="tilemap.png" trans="ff00ff" width="576" height="384"/>
</tileset>
